from fractions import Fraction
import random, subprocess, math
r=random.Random(143)
a=['-0','+0.0','5e-324','2.4703282292062327e-324','1.7976931348623157e308']
for _ in range(15000):
 n=r.randrange(1,100); d=''.join(str(r.randrange(10)) for _ in range(n)); point=r.randrange(n+1); a.append(('-' if r.randrange(2) else '')+d[:point]+'.'+d[point:]+'e'+str(r.randrange(-410,350)))
p=subprocess.run(['/tmp/independent-rc-target'],input='\n'.join(a)+'\n',capture_output=True,text=True,check=True)
errors=[]
for s,v in zip(a,p.stdout.splitlines()):
 f=float(s); mant,_,ex=s.lower().partition('e'); places=len(mant.partition('.')[2]); q=Fraction(10)**(int(ex or '0')-places)
 expected=math.isfinite(f) and not (f==0 and Fraction(s)!=0) and abs(Fraction(f)-Fraction(s)) <= q/2 if math.isfinite(f) else False
 if (v=='true')!=expected: errors.append((s,v,expected))
assert len(p.stdout.splitlines()) == len(a)
print('Exact Fraction oracle cases:',len(a),'mismatches:',len(errors))
assert not errors, errors[:10]
