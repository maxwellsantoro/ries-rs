#[path="/tmp/ries-c94d781-review/src/target.rs"] mod target;
use std::io::{self,BufRead};
fn main(){for line in io::stdin().lock().lines(){let s=line.unwrap(); match s.parse::<f64>() {Ok(f)=>println!("{}",target::validate_decimal_target(f,&s,true).is_ok()),Err(_)=>println!("false")}}}
