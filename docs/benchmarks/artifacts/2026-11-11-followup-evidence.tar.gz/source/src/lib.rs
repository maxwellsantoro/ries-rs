// Allow field reassignment with default in test code - common pattern for config building
#![cfg_attr(test, allow(clippy::field_reassign_with_default))]

//! # RIES-RS: Find algebraic equations given their solution
//!
//! A Rust implementation of Robert Munafo's RIES (RILYBOT Inverse Equation Solver).
//!
//! Given a numeric target value, RIES searches for algebraic equations
//! that have the target as a solution. For example, given π, it finds
//! equations like `x = π`, `x² = 10`, `sin(πx) = 0`, etc.
//!
//! ## Features
//!
//! - **Parallel search** using Rayon for multi-core speedup
//! - **Automatic differentiation** for Newton-Raphson refinement
//! - **User-defined constants and functions** via profiles
//! - **Multiple output formats**: default, pretty (Unicode), Mathematica, SymPy
//! - **Complexity scoring** to find simplest equations first
//!
//! ## Quick Start
//!
//! ```rust,no_run
//! use ries_rs::{search, search::level_to_complexity, GenConfig};
//!
//! let (max_lhs, max_rhs) = level_to_complexity(2);
//! let config = GenConfig {
//!     max_lhs_complexity: max_lhs,
//!     max_rhs_complexity: max_rhs,
//!     ..GenConfig::default()
//! };
//! let matches = search(2.5, &config, 10);
//!
//! // Should find equations like x = 5/2, x-2 = 1/2, etc.
//! assert!(!matches.is_empty());
//! ```
//!
//! ## Command-Line Usage
//!
//! ```bash
//! # Find equations for π
//! ries-rs 3.141592653589793
//!
//! # Higher search level (more results)
//! ries-rs 2.5 -l 5
//!
//! # Restrict to algebraic solutions
//! ries-rs 1.41421356 -a
//! ```
//!
//! ## API Levels
//!
//! The library provides three API levels:
//!
//! ### High-Level API
//!
//! Simple functions for common use cases:
//! - [`search()`] - Find equations for a target value
//!
//! ### Mid-Level API
//!
//! Configuration and control structures:
//! - [`GenConfig`](gen::GenConfig) - Configure expression generation
//! - [`SearchConfig`](search::SearchConfig) - Configure search behavior
//! - [`Match`](search::Match) - A matched equation
//!
//! ### Low-Level API
//!
//! Building blocks for custom implementations:
//! - [`Expression`](expr::Expression) - Symbolic expression representation
//! - [`Symbol`](symbol::Symbol) - Individual symbols (constants, operators)
//! - [`evaluate()`](eval::evaluate) - Evaluate expressions with derivatives
//!
//! ## Modules
//!
//! - [`eval`] - Expression evaluation with automatic differentiation
//! - [`expr`] - Expression representation and manipulation
//! - [`gen`] - Expression generation
//! - [`metrics`] - Match scoring and categorization
//! - [`pool`] - Bounded priority pool for match collection
//! - [`precision`] - Precision abstraction for numeric types
//! - [`profile`] - Profile file support for configuration
//! - [`report`] - Categorized match output
//! - [`search`] - Search algorithms and matching
//! - [`symbol`] - Symbol definitions and type system
//! - [`thresholds`] - Named threshold constants
//! - [`udf`] - User-defined functions

pub mod eval;
pub mod expr;
mod fast_match;
pub mod gen;
mod highprec_verify;
mod manifest;
mod match_summary;
mod metrics;
pub mod pool;
#[cfg(feature = "highprec")]
pub mod precision;
mod presets;
pub mod profile;
mod pslq;
mod report;
pub mod search;
mod solver;
mod stability;
pub mod symbol;
mod symbol_table;
mod thresholds;
pub mod udf;
#[cfg(feature = "wasm")]
mod wasm;

// WASM re-exports (when feature is enabled)
#[cfg(feature = "wasm")]
pub use wasm::{init, list_presets, search as wasm_search, version, SearchOptions, WasmMatch};

// =============================================================================
// Type Aliases
// =============================================================================

/// Type alias for complexity scores
///
/// Complexity scores measure how "simple" an expression is.
/// Lower values indicate simpler expressions that will be shown first.
///
/// Uses `u32` to allow for very long expressions without overflow risk,
/// though practical expressions typically have complexity < 500.
pub type Complexity = u32;

// =============================================================================
// Re-exports for convenience
// =============================================================================

// High-level API
pub use search::search;
pub use solver::{
    canonical_expression_key, solve_for_x_at, solve_for_x_at_with_context,
    solve_for_x_rhs_expression,
};

// Fast exact match detection
pub use fast_match::{
    find_certified_fast_match, find_fast_match, find_fast_match_with_context,
    non_atomic_equation_complexity_floor, FastMatchConfig,
};

// Common types
pub use eval::{EvalContext, EvalError, EvalResult, DEFAULT_TRIG_ARGUMENT_SCALE};
pub use expr::{Expression, OutputFormat};
pub use gen::{
    expression_respects_constraints, ExpressionConstraintOptions, GenConfig,
    UserFunctionConstraints,
};
pub use profile::{Profile, UserConstant};
pub use search::{Match, SearchConfig, SearchContext, SearchStats};
pub use symbol::{NumType, Symbol};
pub use symbol_table::SymbolTable;
pub use udf::UserFunction;

// Threshold constants
pub use thresholds::{DEGENERATE_DERIVATIVE, EXACT_MATCH_TOLERANCE, NEWTON_TOLERANCE};

// High-precision types (when feature is enabled)
#[cfg(feature = "highprec")]
pub use precision::{HighPrec, RiesFloat, DEFAULT_PRECISION};

// Manifest types for reproducibility
pub use manifest::{MatchInfo, RunManifest, SearchConfigInfo, UserConstantInfo};
pub use match_summary::MatchSummary;

// Structured reporting and analysis
pub use highprec_verify::{
    format_verification_report, format_verification_report_with, verify_matches_highprec,
    verify_matches_highprec_with_trig_scale, VerificationResult, VerificationStatus,
};
pub use metrics::MatchMetrics;
pub use presets::{print_presets, Preset};
pub use pslq::{find_integer_relation, find_rational_approximation, IntegerRelation, PslqConfig};
pub use report::{DisplayFormat as ReportDisplayFormat, Report, ReportConfig};
pub use stability::{
    format_stability_report, format_stability_report_with, StabilityAnalyzer, StabilityClass,
    StabilityConfig, StabilityResult,
};

/// Exact decimal checks at the floating-point target boundary.
pub mod target;
