//! Expression representation and manipulation
//!
//! Expressions are stored in postfix (reverse Polish) notation.

use crate::symbol::{NumType, Seft, Symbol};
use smallvec::SmallVec;
use std::fmt;
use std::hash::{Hash, Hasher};

/// Maximum expression length (matching C version's MAX_ELEN)
pub const MAX_EXPR_LEN: usize = 21;

/// Output format for expression display
#[derive(Debug, Clone, Copy, Default)]
pub enum OutputFormat {
    /// Default RIES format
    #[default]
    Default,
    /// Pretty format with Unicode symbols (π, ℯ, φ, √)
    Pretty,
    /// Mathematica-compatible syntax
    Mathematica,
    /// SymPy Python syntax
    SymPy,
}

/// A symbolic expression in postfix notation.
///
/// Most expressions store symbols inline. Solver-generated decimal annotations
/// use a boxed variant, so ordinary search expressions stay compact and avoid
/// global state. Annotated expressions own their spans and clone independently.
#[derive(Clone)]
pub struct Expression {
    symbols: SymbolStorage,
    complexity: u32,
    contains_x: bool,
}

#[derive(Clone)]
enum SymbolStorage {
    Plain(SmallVec<[Symbol; MAX_EXPR_LEN]>),
    Annotated(Box<AnnotatedSymbols>),
}

#[derive(Clone)]
struct AnnotatedSymbols {
    symbols: SmallVec<[Symbol; MAX_EXPR_LEN]>,
    spans: Vec<(u32, u32, u64)>,
}

/// Whether `child` must be parenthesized under `parent`.
///
/// Power is right-associative, so `(a^b)^c` needs parentheses and `a^(b^c)`
/// prints as `a^b^c`. Addition, subtraction, multiplication, and division are
/// left-associative, so an equal-precedence expression on the right
/// (`a-(b-c)`, `a-(b+c)`) needs parentheses.
fn infix_needs_paren(
    parent_prec: u8,
    child_prec: u8,
    is_right_assoc: bool,
    is_right_operand: bool,
) -> bool {
    if child_prec < parent_prec {
        return true;
    }
    if child_prec == parent_prec {
        if is_right_assoc {
            return !is_right_operand;
        }
        return is_right_operand;
    }
    false
}

/// Parenthesize a subexpression that is not a primary (atom or function call).
fn infix_paren_unless_primary(s: &str, prec: u8) -> String {
    if prec < 100 {
        format!("({})", s)
    } else {
        s.to_string()
    }
}

/// Log bases that are themselves calls (`log_sqrt(2)(3)`) or operators need grouping.
fn infix_group_log_base(s: &str, prec: u8) -> String {
    if prec < 100 || s.contains('(') {
        format!("({})", s)
    } else {
        s.to_string()
    }
}

fn format_trig(name: &str, argument: &str, scale: f64, format: OutputFormat) -> String {
    let default_scale = scale == crate::eval::DEFAULT_TRIG_ARGUMENT_SCALE;
    if default_scale && matches!(format, OutputFormat::Default | OutputFormat::Pretty) {
        return format!("{name}pi({argument})");
    }
    let argument = if default_scale {
        let pi = if matches!(format, OutputFormat::Mathematica) {
            "Pi"
        } else {
            "pi"
        };
        format!("{pi}*{argument}")
    } else if scale == 1.0 {
        argument.to_owned()
    } else {
        format!("{scale}*({argument})")
    };
    if matches!(format, OutputFormat::Mathematica) {
        let mathematica_name = match name {
            "sin" => "Sin",
            "cos" => "Cos",
            _ => "Tan",
        };
        format!("{mathematica_name}[{argument}]")
    } else {
        format!("{name}({argument})")
    }
}

/// Decimal digits of a finite integer `f64`, with no exponent and no rounding.
///
/// Every finite value with magnitude at least 2^52 is an integer. Powers of two
/// past 2^53 are exact too, but `Display` would print them in scientific
/// notation and a `u64` cannot hold 2^64. The digits are the integer value of
/// the significand, shifted by the unbiased exponent.
pub(crate) fn format_exact_f64_integer(value: f64) -> String {
    if !value.is_finite() {
        return "0".to_string();
    }
    if value == 0.0 {
        return "0".to_string();
    }
    let negative = value.is_sign_negative();
    let bits = value.abs().to_bits();
    let biased = ((bits >> 52) & 0x7ff) as i32;
    if biased == 0 {
        return "0".to_string();
    }
    let mut significand = (bits & ((1u64 << 52) - 1)) | (1u64 << 52);
    // Little-endian decimal digits of the 53-bit significand.
    let mut digits = Vec::new();
    while significand > 0 {
        digits.push((significand % 10) as u8);
        significand /= 10;
    }
    let shift = biased - 1023 - 52;
    if shift > 0 {
        for _ in 0..shift {
            let mut carry = 0u8;
            for digit in &mut digits {
                let scaled = *digit * 2 + carry;
                *digit = scaled % 10;
                carry = scaled / 10;
            }
            if carry > 0 {
                digits.push(carry);
            }
        }
    } else if shift < 0 {
        for _ in 0..(-shift) {
            let mut remainder = 0u8;
            for digit in digits.iter_mut().rev() {
                let scaled = remainder * 10 + *digit;
                *digit = scaled / 2;
                remainder = scaled % 2;
            }
            while digits.last() == Some(&0) && digits.len() > 1 {
                digits.pop();
            }
        }
    }
    while digits.last() == Some(&0) && digits.len() > 1 {
        digits.pop();
    }
    let mut text = String::with_capacity(digits.len() + usize::from(negative));
    if negative {
        text.push('-');
    }
    for digit in digits.iter().rev() {
        text.push(char::from(b'0' + *digit));
    }
    text
}

fn infix_maybe_paren(
    s: &str,
    prec: u8,
    parent_prec: u8,
    is_right_assoc: bool,
    is_right: bool,
) -> String {
    // `1--x`, `2*-x`, and `1/-x` are not primaries. Parenthesize a leading minus
    // on the right of an operator.
    let leading_minus = is_right && s.starts_with('-');
    if leading_minus || infix_needs_paren(parent_prec, prec, is_right_assoc, is_right) {
        format!("({})", s)
    } else {
        s.to_string()
    }
}

impl Expression {
    /// Create an empty expression
    pub fn new() -> Self {
        Self {
            symbols: SymbolStorage::Plain(SmallVec::new()),
            complexity: 0,
            contains_x: false,
        }
    }

    /// Create an expression from a slice of symbols
    #[cfg(test)]
    pub fn from_symbols(symbols: &[Symbol]) -> Self {
        // Use saturating_add to prevent overflow with maliciously large weights
        let complexity: u32 = symbols
            .iter()
            .map(|s| s.weight())
            .fold(0u32, |acc, w| acc.saturating_add(w));
        let contains_x = symbols.contains(&Symbol::X);
        Self {
            symbols: SymbolStorage::Plain(SmallVec::from_slice(symbols)),
            complexity,
            contains_x,
        }
    }

    /// Parse a well-formed postfix expression (e.g., "32s1+s*").
    ///
    /// This validates stack discipline while parsing, so malformed or incomplete
    /// postfix strings return `None` instead of constructing an expression that
    /// will later panic during formatting.
    pub fn parse(s: &str) -> Option<Self> {
        let mut symbols = SmallVec::new();
        for c in s.chars() {
            symbols.push(Symbol::from_postfix_char(c)?);
        }
        if !Self::is_valid_postfix(&symbols) {
            return None;
        }
        // Use saturating_add to prevent overflow with maliciously large weights
        let complexity: u32 = symbols
            .iter()
            .map(|s: &Symbol| s.weight())
            .fold(0u32, |acc, w| acc.saturating_add(w));
        let contains_x = symbols.contains(&Symbol::X);
        Some(Self {
            symbols: SymbolStorage::Plain(symbols),
            complexity,
            contains_x,
        })
    }

    /// Get the symbols in this expression
    #[inline]
    pub fn symbols(&self) -> &[Symbol] {
        match &self.symbols {
            SymbolStorage::Plain(symbols) => symbols,
            SymbolStorage::Annotated(annotated) => &annotated.symbols,
        }
    }

    #[inline]
    fn symbols_mut(&mut self) -> &mut SmallVec<[Symbol; MAX_EXPR_LEN]> {
        match &mut self.symbols {
            SymbolStorage::Plain(symbols) => symbols,
            SymbolStorage::Annotated(annotated) => &mut annotated.symbols,
        }
    }

    fn literal_spans(&self) -> &[(u32, u32, u64)] {
        match &self.symbols {
            SymbolStorage::Plain(_) => &[],
            SymbolStorage::Annotated(annotated) => &annotated.spans,
        }
    }

    fn literal_spans_mut(&mut self) -> &mut Vec<(u32, u32, u64)> {
        if matches!(self.symbols, SymbolStorage::Plain(_)) {
            let SymbolStorage::Plain(symbols) =
                std::mem::replace(&mut self.symbols, SymbolStorage::Plain(SmallVec::new()))
            else {
                unreachable!()
            };
            self.symbols = SymbolStorage::Annotated(Box::new(AnnotatedSymbols {
                symbols,
                spans: Vec::new(),
            }));
        }
        match &mut self.symbols {
            SymbolStorage::Annotated(annotated) => &mut annotated.spans,
            SymbolStorage::Plain(_) => unreachable!(),
        }
    }

    /// Get the expression length
    #[inline]
    pub fn len(&self) -> usize {
        self.symbols().len()
    }

    /// Check if expression is empty
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.symbols().is_empty()
    }

    /// Get the complexity score
    #[inline]
    pub fn complexity(&self) -> u32 {
        self.complexity
    }

    /// Check if this expression contains the variable x
    #[inline]
    pub fn contains_x(&self) -> bool {
        self.contains_x
    }

    /// Count occurrences of a symbol in this expression.
    #[inline]
    pub fn count_symbol(&self, sym: Symbol) -> u32 {
        self.symbols().iter().filter(|&&s| s == sym).count() as u32
    }

    /// Check if this is a valid complete expression (stack depth = 1)
    ///
    /// This method is part of the public API for external consumers who may want to
    /// validate expressions before processing them.
    #[allow(dead_code)]
    pub fn is_valid(&self) -> bool {
        Self::is_valid_postfix(self.symbols())
    }

    fn is_valid_postfix(symbols: &[Symbol]) -> bool {
        let mut depth: i32 = 0;
        for sym in symbols {
            match sym.seft() {
                Seft::A => depth += 1,
                Seft::B => { /* pop 1, push 1 - no change */ }
                Seft::C => depth -= 1, // pop 2, push 1
            }
            if depth < 1 {
                return false; // Stack underflow
            }
        }
        depth == 1
    }

    /// Append a symbol to this expression
    pub fn push(&mut self, sym: Symbol) {
        // Use saturating_add to prevent overflow with many operations
        self.complexity = self.complexity.saturating_add(sym.weight());
        if sym == Symbol::X {
            self.contains_x = true;
        }
        self.symbols_mut().push(sym);
    }

    /// Remember that the whole expression is the finite decimal literal `value`.
    ///
    /// Later combinations shift the recorded span with the symbols. Evaluation
    /// and printing use this value, not the postfix scaffold under the span.
    pub(crate) fn mark_decimal_literal(&mut self, value: f64) {
        if !value.is_finite() {
            return;
        }
        let len = self.symbols().len();
        if len == 0 || len > u32::MAX as usize {
            return;
        }
        self.literal_spans_mut()
            .push((0, len as u32, value.to_bits()));
    }

    pub(crate) fn append_decimal_literals(&mut self, other: &Expression, shift: u32) {
        if other.literal_spans().is_empty() {
            return;
        }
        self.literal_spans_mut().extend(
            other
                .literal_spans()
                .iter()
                .map(|&(start, len, bits)| (start.saturating_add(shift), len, bits)),
        );
    }

    fn trim_decimal_literals(&mut self) {
        let n = self.symbols().len() as u32;
        if let SymbolStorage::Annotated(annotated) = &mut self.symbols {
            annotated
                .spans
                .retain(|(start, len, _)| start.saturating_add(*len) <= n);
        }
        if matches!(&self.symbols, SymbolStorage::Annotated(a) if a.spans.is_empty()) {
            let SymbolStorage::Annotated(annotated) =
                std::mem::replace(&mut self.symbols, SymbolStorage::Plain(SmallVec::new()))
            else {
                unreachable!()
            };
            self.symbols = SymbolStorage::Plain(annotated.symbols);
        }
    }

    /// Solver-inserted decimals are rare; the evaluator skips scanning otherwise.
    #[inline(always)]
    pub(crate) fn has_decimal_literals(&self) -> bool {
        matches!(self.symbols, SymbolStorage::Annotated(_))
    }

    /// When a decimal literal starts at `index`, its symbol length and value.
    pub(crate) fn decimal_literal_at(&self, index: usize) -> Option<(usize, f64)> {
        self.literal_spans().iter().find_map(|&(start, len, bits)| {
            (start as usize == index && len > 0).then_some((len as usize, f64::from_bits(bits)))
        })
    }

    /// If a decimal literal starts at `index`, return its text and advance past it.
    fn take_decimal_literal(&self, index: &mut usize) -> Option<String> {
        let (len, value) = self.decimal_literal_at(*index)?;
        *index += len;
        Some(if value == value.trunc() {
            format_exact_f64_integer(value)
        } else {
            value.to_string()
        })
    }

    /// Remove the last symbol
    pub fn pop(&mut self) -> Option<Symbol> {
        let sym = self.symbols_mut().pop()?;
        // Use saturating_sub to prevent underflow (shouldn't happen with valid state)
        self.complexity = self.complexity.saturating_sub(sym.weight());
        // Recompute contains_x after popping
        if sym == Symbol::X {
            self.contains_x = self.symbols().contains(&Symbol::X);
        }
        // Search never annotates integers. Skip span maintenance unless one is present.
        if self.has_decimal_literals() {
            self.trim_decimal_literals();
        }
        Some(sym)
    }

    /// Append a symbol using a symbol table for weight lookup
    ///
    /// This is the table-driven version that uses per-run configuration
    /// instead of global overrides.
    pub fn push_with_table(&mut self, sym: Symbol, table: &crate::symbol_table::SymbolTable) {
        // Use saturating_add to prevent overflow with many operations
        self.complexity = self.complexity.saturating_add(table.weight(sym));
        if sym == Symbol::X {
            self.contains_x = true;
        }
        self.symbols_mut().push(sym);
    }

    /// Remove the last symbol using a symbol table for weight lookup
    ///
    /// This is the table-driven version that uses per-run configuration
    /// instead of global overrides.
    pub fn pop_with_table(&mut self, table: &crate::symbol_table::SymbolTable) -> Option<Symbol> {
        let sym = self.symbols_mut().pop()?;
        // Use saturating_sub to prevent underflow (shouldn't happen with valid state)
        self.complexity = self.complexity.saturating_sub(table.weight(sym));
        // Recompute contains_x after popping
        if sym == Symbol::X {
            self.contains_x = self.symbols().contains(&Symbol::X);
        }
        if self.has_decimal_literals() {
            self.trim_decimal_literals();
        }
        Some(sym)
    }

    /// Get the postfix string representation
    pub fn to_postfix(&self) -> String {
        self.symbols().iter().map(|s| s.to_postfix_char()).collect()
    }

    /// Convert to infix notation for display
    ///
    /// Uses proper operator precedence and associativity rules:
    /// - Precedence levels (higher = tighter binding):
    ///   - 100: Atoms (constants, x, function calls)
    ///   - 9: Power (right-associative), including `^2` and `e^`
    ///   - 8: Unary minus
    ///   - 6: Multiplication, division, and reciprocal (`1/`)
    ///   - 4: Addition, subtraction
    /// - Right-associative operators (power) bind right-to-left
    /// - Left-associative operators bind left-to-right
    /// - Printed grouping round-trips: parsing the infix with these rules
    ///   yields the same value as the postfix expression. Unary results keep
    ///   the precedence of the operator they render as, so chains such as
    ///   `-(1/(1/(-phi)))` are not flattened.
    ///
    /// Convert to infix notation, returning `Err(EvalError::StackUnderflow)` if
    /// the expression is malformed (e.g. a binary operator with no operands).
    ///
    /// Prefer this over [`to_infix`](Self::to_infix) when the expression may come
    /// from untrusted or user-provided input.
    pub fn try_to_infix(&self) -> Result<String, crate::eval::EvalError> {
        self.try_to_infix_with_context(None, crate::eval::DEFAULT_TRIG_ARGUMENT_SCALE)
    }

    pub(crate) fn try_to_infix_with_context(
        &self,
        table: Option<&crate::symbol_table::SymbolTable>,
        trig_scale: f64,
    ) -> Result<String, crate::eval::EvalError> {
        let name = |symbol: Symbol| {
            table.map_or_else(
                || symbol.display_name(),
                |table| table.name(symbol).to_owned(),
            )
        };
        const PREC_ATOM: u8 = 100;
        const PREC_POWER: u8 = 9;
        const PREC_UNARY: u8 = 8;
        const PREC_MUL: u8 = 6;
        const PREC_ADD: u8 = 4;

        // Track the literal symbol separately from the text, since a profile
        // can give any symbol the display name "1".
        let mut stack: Vec<(String, u8, bool)> = Vec::new();

        let mut index = 0;
        while index < self.symbols().len() {
            if let Some(literal) = self.take_decimal_literal(&mut index) {
                stack.push((literal, PREC_ATOM, false));
                continue;
            }
            let sym = self.symbols()[index];
            index += 1;
            match sym.seft() {
                Seft::A => {
                    let text = name(sym);
                    let literal_one = sym == Symbol::One && text == "1";
                    stack.push((text, PREC_ATOM, literal_one));
                }
                Seft::B => {
                    let (arg, arg_prec, _) =
                        stack.pop().ok_or(crate::eval::EvalError::StackUnderflow)?;
                    // Unary results carry the precedence of the operator they
                    // print as. Tagging them as atoms drops parentheses, so
                    // `-(1/(1/(-phi)))` used to render as `-1/1/-phi`.
                    // Negation's operand is parenthesized unless it binds
                    // strictly tighter than unary minus (power does: `-x^2`).
                    let (result, prec) = match sym {
                        Symbol::Neg => {
                            let arg_s = infix_maybe_paren(&arg, arg_prec, PREC_POWER, false, false);
                            (format!("-{}", arg_s), PREC_UNARY)
                        }
                        Symbol::Recip => {
                            // Denominator is the right side of a division.
                            let arg_s =
                                infix_maybe_paren(&arg, arg_prec, PREC_MUL + 1, false, true);
                            (format!("1/{}", arg_s), PREC_MUL)
                        }
                        Symbol::Sqrt => (format!("sqrt({})", arg), PREC_ATOM),
                        Symbol::Square => {
                            let arg_s = infix_maybe_paren(&arg, arg_prec, PREC_POWER, true, false);
                            (format!("{}^2", arg_s), PREC_POWER)
                        }
                        Symbol::Ln => (format!("ln({})", arg), PREC_ATOM),
                        Symbol::Exp => {
                            let arg_s = infix_maybe_paren(&arg, arg_prec, PREC_POWER, true, true);
                            (format!("e^{}", arg_s), PREC_POWER)
                        }
                        Symbol::SinPi => (
                            format_trig("sin", &arg, trig_scale, OutputFormat::Default),
                            PREC_ATOM,
                        ),
                        Symbol::CosPi => (
                            format_trig("cos", &arg, trig_scale, OutputFormat::Default),
                            PREC_ATOM,
                        ),
                        Symbol::TanPi => (
                            format_trig("tan", &arg, trig_scale, OutputFormat::Default),
                            PREC_ATOM,
                        ),
                        Symbol::LambertW => (format!("W({})", arg), PREC_ATOM),
                        Symbol::UserFunction0
                        | Symbol::UserFunction1
                        | Symbol::UserFunction2
                        | Symbol::UserFunction3
                        | Symbol::UserFunction4
                        | Symbol::UserFunction5
                        | Symbol::UserFunction6
                        | Symbol::UserFunction7
                        | Symbol::UserFunction8
                        | Symbol::UserFunction9
                        | Symbol::UserFunction10
                        | Symbol::UserFunction11
                        | Symbol::UserFunction12
                        | Symbol::UserFunction13
                        | Symbol::UserFunction14
                        | Symbol::UserFunction15 => (format!("{}({})", name(sym), arg), PREC_ATOM),
                        _ => ("?".to_string(), PREC_ATOM),
                    };
                    stack.push((result, prec, false));
                }
                Seft::C => {
                    let (b, b_prec, b_is_one) =
                        stack.pop().ok_or(crate::eval::EvalError::StackUnderflow)?;
                    let (a, a_prec, a_is_one) =
                        stack.pop().ok_or(crate::eval::EvalError::StackUnderflow)?;
                    if sym == Symbol::Mul && (a_is_one || b_is_one) {
                        let operand = if a_is_one {
                            (b, b_prec, b_is_one)
                        } else {
                            (a, a_prec, a_is_one)
                        };
                        stack.push(operand);
                        continue;
                    }
                    let (result, prec) = match sym {
                        Symbol::Add => {
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_ADD, false, true);
                            (format!("{}+{}", a, b_s), PREC_ADD)
                        }
                        Symbol::Sub => {
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_ADD, false, true);
                            (format!("{}-{}", a, b_s), PREC_ADD)
                        }
                        Symbol::Mul => {
                            let a_s = infix_maybe_paren(&a, a_prec, PREC_MUL, false, false);
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_MUL, false, true);
                            if a_prec == PREC_ATOM
                                && a_s.bytes().all(|byte| byte.is_ascii_digit())
                                && b_s.chars().next().is_some_and(|c| c.is_alphabetic())
                            {
                                (format!("{} {}", a_s, b_s), PREC_MUL)
                            } else {
                                (format!("{}*{}", a_s, b_s), PREC_MUL)
                            }
                        }
                        Symbol::Div => {
                            let a_s = infix_maybe_paren(&a, a_prec, PREC_MUL, false, false);
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_MUL + 1, false, true);
                            (format!("{}/{}", a_s, b_s), PREC_MUL)
                        }
                        Symbol::Pow => {
                            let a_s = infix_maybe_paren(&a, a_prec, PREC_POWER, true, false);
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_POWER, true, true);
                            (format!("{}^{}", a_s, b_s), PREC_POWER)
                        }
                        Symbol::Root => {
                            let index = infix_paren_unless_primary(&a, a_prec);
                            let radicand = infix_paren_unless_primary(&b, b_prec);
                            (format!("{}\"/{}", index, radicand), PREC_POWER)
                        }
                        Symbol::Log => {
                            let base = infix_group_log_base(&a, a_prec);
                            (format!("log_{}({})", base, b), PREC_ATOM)
                        }
                        Symbol::Atan2 => (format!("atan2({}, {})", a, b), PREC_ATOM),
                        _ => unreachable!(),
                    };
                    stack.push((result, prec, false));
                }
            }
        }

        Ok(stack.pop().map(|(s, _, _)| s).unwrap_or_else(|| "?".into()))
    }

    pub fn to_infix(&self) -> String {
        self.try_to_infix()
            .expect("stack underflow in to_infix: expression is not valid postfix")
    }

    /// Format as infix, falling back to postfix when the expression is malformed.
    ///
    /// Prefer this over [`to_infix`](Self::to_infix) at FFI and other untrusted-output
    /// boundaries where a panic would be unacceptable.
    pub fn to_infix_or_postfix(&self) -> String {
        self.try_to_infix().unwrap_or_else(|_| self.to_postfix())
    }

    /// Convert to infix notation using a symbol table for display names
    ///
    /// This is the table-driven version that uses per-run configuration
    /// instead of global overrides for symbol display names.
    pub fn to_infix_with_table(&self, table: &crate::symbol_table::SymbolTable) -> String {
        self.to_infix_with_context(
            OutputFormat::Default,
            Some(table),
            crate::eval::DEFAULT_TRIG_ARGUMENT_SCALE,
        )
    }

    /// Convert to infix notation with the specified format.
    pub fn to_infix_with_format(&self, format: OutputFormat) -> String {
        self.to_infix_with_context(format, None, crate::eval::DEFAULT_TRIG_ARGUMENT_SCALE)
    }

    /// Format an equation side with the active trig scale and, in default and
    /// pretty output, the active symbol names.
    pub fn to_infix_with_context(
        &self,
        format: OutputFormat,
        table: Option<&crate::symbol_table::SymbolTable>,
        trig_scale: f64,
    ) -> String {
        match format {
            OutputFormat::Default | OutputFormat::Pretty => {
                let infix = self
                    .try_to_infix_with_context(table, trig_scale)
                    .expect("stack underflow in to_infix: expression is not valid postfix");
                if matches!(format, OutputFormat::Pretty) {
                    infix
                        .replace("pi", "π")
                        .replace("sqrt(", "√(")
                        .replace("^2", "²")
                } else {
                    infix
                }
            }
            OutputFormat::Mathematica => self.to_infix_mathematica_with_scale(trig_scale),
            OutputFormat::SymPy => self.to_infix_sympy_with_scale(trig_scale),
        }
    }

    /// Count the number of operators (non-atoms) in the expression
    pub fn operator_count(&self) -> usize {
        self.symbols()
            .iter()
            .filter(|sym| sym.seft() != Seft::A)
            .count()
    }

    /// Compute the maximum depth of the expression tree
    pub fn tree_depth(&self) -> usize {
        let mut stack: Vec<usize> = Vec::with_capacity(self.len());
        for &sym in self.symbols() {
            match sym.seft() {
                Seft::A => stack.push(1),
                Seft::B => {
                    let Some(arg_depth) = stack.pop() else {
                        return 0;
                    };
                    stack.push(arg_depth.saturating_add(1));
                }
                Seft::C => {
                    let Some(rhs_depth) = stack.pop() else {
                        return 0;
                    };
                    let Some(lhs_depth) = stack.pop() else {
                        return 0;
                    };
                    stack.push(lhs_depth.max(rhs_depth).saturating_add(1));
                }
            }
        }
        if stack.len() == 1 {
            stack[0]
        } else {
            0
        }
    }

    pub fn to_infix_mathematica(&self) -> String {
        self.to_infix_mathematica_with_scale(crate::eval::DEFAULT_TRIG_ARGUMENT_SCALE)
    }

    fn to_infix_mathematica_with_scale(&self, trig_scale: f64) -> String {
        const PREC_ATOM: u8 = 100;
        const PREC_POWER: u8 = 9;
        const PREC_UNARY: u8 = 8;
        const PREC_MUL: u8 = 6;
        const PREC_ADD: u8 = 4;

        let mut stack: Vec<(String, u8)> = Vec::new();

        let mut index = 0;
        while index < self.symbols().len() {
            if let Some(literal) = self.take_decimal_literal(&mut index) {
                stack.push((literal, PREC_ATOM));
                continue;
            }
            let sym = self.symbols()[index];
            index += 1;
            match sym.seft() {
                Seft::A => {
                    let s = match sym {
                        Symbol::Pi => "Pi",
                        Symbol::E => "E",
                        Symbol::Phi => "GoldenRatio",
                        Symbol::Gamma => "EulerGamma",
                        Symbol::Apery => "Zeta[3]",
                        Symbol::Catalan => "Catalan",
                        _ => "",
                    };
                    let name = if s.is_empty() {
                        sym.display_name()
                    } else {
                        s.to_string()
                    };
                    stack.push((name, PREC_ATOM));
                }
                Seft::B => {
                    let (arg, arg_prec) = stack
                        .pop()
                        .expect("stack underflow in to_infix: expression is not valid postfix");
                    let grouped = infix_paren_unless_primary(&arg, arg_prec);
                    let (result, prec) = match sym {
                        Symbol::Neg => {
                            let s = infix_maybe_paren(&arg, arg_prec, PREC_POWER, false, false);
                            (format!("-{}", s), PREC_UNARY)
                        }
                        Symbol::Recip => {
                            let s = infix_maybe_paren(&arg, arg_prec, PREC_MUL + 1, false, true);
                            (format!("1/{}", s), PREC_MUL)
                        }
                        Symbol::Sqrt => (format!("Sqrt[{}]", arg), PREC_ATOM),
                        Symbol::Square => {
                            let s = infix_maybe_paren(&arg, arg_prec, PREC_POWER, true, false);
                            (format!("{}^2", s), PREC_POWER)
                        }
                        Symbol::Ln => (format!("Log[{}]", arg), PREC_ATOM),
                        Symbol::Exp => (format!("Exp[{}]", arg), PREC_ATOM),
                        Symbol::SinPi => (
                            format_trig("sin", &grouped, trig_scale, OutputFormat::Mathematica),
                            PREC_ATOM,
                        ),
                        Symbol::CosPi => (
                            format_trig("cos", &grouped, trig_scale, OutputFormat::Mathematica),
                            PREC_ATOM,
                        ),
                        Symbol::TanPi => (
                            format_trig("tan", &grouped, trig_scale, OutputFormat::Mathematica),
                            PREC_ATOM,
                        ),
                        Symbol::LambertW => (format!("ProductLog[{}]", arg), PREC_ATOM),
                        Symbol::UserFunction0
                        | Symbol::UserFunction1
                        | Symbol::UserFunction2
                        | Symbol::UserFunction3
                        | Symbol::UserFunction4
                        | Symbol::UserFunction5
                        | Symbol::UserFunction6
                        | Symbol::UserFunction7
                        | Symbol::UserFunction8
                        | Symbol::UserFunction9
                        | Symbol::UserFunction10
                        | Symbol::UserFunction11
                        | Symbol::UserFunction12
                        | Symbol::UserFunction13
                        | Symbol::UserFunction14
                        | Symbol::UserFunction15 => {
                            (format!("{}[{}]", sym.display_name(), arg), PREC_ATOM)
                        }
                        _ => ("?".to_string(), PREC_ATOM),
                    };
                    stack.push((result, prec));
                }
                Seft::C => {
                    let (b, b_prec) = stack
                        .pop()
                        .expect("stack underflow in to_infix: expression is not valid postfix");
                    let (a, a_prec) = stack
                        .pop()
                        .expect("stack underflow in to_infix: expression is not valid postfix");
                    let (result, prec) = match sym {
                        Symbol::Add => {
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_ADD, false, true);
                            (format!("{}+{}", a, b_s), PREC_ADD)
                        }
                        Symbol::Sub => {
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_ADD, false, true);
                            (format!("{}-{}", a, b_s), PREC_ADD)
                        }
                        Symbol::Mul => {
                            let a_s = infix_maybe_paren(&a, a_prec, PREC_MUL, false, false);
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_MUL, false, true);
                            (format!("{}*{}", a_s, b_s), PREC_MUL)
                        }
                        Symbol::Div => {
                            let a_s = infix_maybe_paren(&a, a_prec, PREC_MUL, false, false);
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_MUL + 1, false, true);
                            (format!("{}/{}", a_s, b_s), PREC_MUL)
                        }
                        Symbol::Pow => {
                            let a_s = infix_maybe_paren(&a, a_prec, PREC_POWER, true, false);
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_POWER, true, true);
                            (format!("{}^{}", a_s, b_s), PREC_POWER)
                        }
                        Symbol::Root => {
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_POWER, true, false);
                            let a_s = infix_paren_unless_primary(&a, a_prec);
                            (format!("{}^(1/{})", b_s, a_s), PREC_POWER)
                        }
                        Symbol::Log => (format!("Log[{}, {}]", a, b), PREC_ATOM),
                        Symbol::Atan2 => (format!("ArcTan[{}, {}]", b, a), PREC_ATOM),
                        _ => unreachable!(),
                    };
                    stack.push((result, prec));
                }
            }
        }

        stack
            .pop()
            .map(|(s, _)| s)
            .unwrap_or_else(|| "?".to_string())
    }

    pub fn to_infix_sympy(&self) -> String {
        self.to_infix_sympy_with_scale(crate::eval::DEFAULT_TRIG_ARGUMENT_SCALE)
    }

    fn to_infix_sympy_with_scale(&self, trig_scale: f64) -> String {
        const PREC_ATOM: u8 = 100;
        const PREC_POWER: u8 = 9;
        const PREC_UNARY: u8 = 8;
        const PREC_MUL: u8 = 6;
        const PREC_ADD: u8 = 4;

        let mut stack: Vec<(String, u8)> = Vec::new();

        let mut index = 0;
        while index < self.symbols().len() {
            if let Some(literal) = self.take_decimal_literal(&mut index) {
                stack.push((literal, PREC_ATOM));
                continue;
            }
            let sym = self.symbols()[index];
            index += 1;
            match sym.seft() {
                Seft::A => {
                    let s = match sym {
                        Symbol::Pi => "pi",
                        Symbol::E => "E",
                        Symbol::Phi => "GoldenRatio",
                        Symbol::Gamma => "EulerGamma",
                        Symbol::Apery => "zeta(3)",
                        Symbol::Catalan => "Catalan",
                        _ => "",
                    };
                    let name = if s.is_empty() {
                        sym.display_name()
                    } else {
                        s.to_string()
                    };
                    stack.push((name, PREC_ATOM));
                }
                Seft::B => {
                    let (arg, arg_prec) = stack
                        .pop()
                        .expect("stack underflow in to_infix: expression is not valid postfix");
                    let grouped = infix_paren_unless_primary(&arg, arg_prec);
                    let (result, prec) = match sym {
                        Symbol::Neg => {
                            let s = infix_maybe_paren(&arg, arg_prec, PREC_POWER, false, false);
                            (format!("-{}", s), PREC_UNARY)
                        }
                        Symbol::Recip => {
                            let s = infix_maybe_paren(&arg, arg_prec, PREC_MUL + 1, false, true);
                            (format!("1/{}", s), PREC_MUL)
                        }
                        Symbol::Sqrt => (format!("sqrt({})", arg), PREC_ATOM),
                        Symbol::Square => {
                            let s = infix_maybe_paren(&arg, arg_prec, PREC_POWER, true, false);
                            (format!("{}**2", s), PREC_POWER)
                        }
                        Symbol::Ln => (format!("log({})", arg), PREC_ATOM),
                        Symbol::Exp => (format!("exp({})", arg), PREC_ATOM),
                        Symbol::SinPi => (
                            format_trig("sin", &grouped, trig_scale, OutputFormat::SymPy),
                            PREC_ATOM,
                        ),
                        Symbol::CosPi => (
                            format_trig("cos", &grouped, trig_scale, OutputFormat::SymPy),
                            PREC_ATOM,
                        ),
                        Symbol::TanPi => (
                            format_trig("tan", &grouped, trig_scale, OutputFormat::SymPy),
                            PREC_ATOM,
                        ),
                        Symbol::LambertW => (format!("lambertw({})", arg), PREC_ATOM),
                        Symbol::UserFunction0
                        | Symbol::UserFunction1
                        | Symbol::UserFunction2
                        | Symbol::UserFunction3
                        | Symbol::UserFunction4
                        | Symbol::UserFunction5
                        | Symbol::UserFunction6
                        | Symbol::UserFunction7
                        | Symbol::UserFunction8
                        | Symbol::UserFunction9
                        | Symbol::UserFunction10
                        | Symbol::UserFunction11
                        | Symbol::UserFunction12
                        | Symbol::UserFunction13
                        | Symbol::UserFunction14
                        | Symbol::UserFunction15 => {
                            (format!("{}({})", sym.display_name(), arg), PREC_ATOM)
                        }
                        _ => ("?".to_string(), PREC_ATOM),
                    };
                    stack.push((result, prec));
                }
                Seft::C => {
                    let (b, b_prec) = stack
                        .pop()
                        .expect("stack underflow in to_infix: expression is not valid postfix");
                    let (a, a_prec) = stack
                        .pop()
                        .expect("stack underflow in to_infix: expression is not valid postfix");
                    let (result, prec) = match sym {
                        Symbol::Add => {
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_ADD, false, true);
                            (format!("{}+{}", a, b_s), PREC_ADD)
                        }
                        Symbol::Sub => {
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_ADD, false, true);
                            (format!("{}-{}", a, b_s), PREC_ADD)
                        }
                        Symbol::Mul => {
                            let a_s = infix_maybe_paren(&a, a_prec, PREC_MUL, false, false);
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_MUL, false, true);
                            (format!("{}*{}", a_s, b_s), PREC_MUL)
                        }
                        Symbol::Div => {
                            let a_s = infix_maybe_paren(&a, a_prec, PREC_MUL, false, false);
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_MUL + 1, false, true);
                            (format!("{}/{}", a_s, b_s), PREC_MUL)
                        }
                        Symbol::Pow => {
                            let a_s = infix_maybe_paren(&a, a_prec, PREC_POWER, true, false);
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_POWER, true, true);
                            (format!("{}**{}", a_s, b_s), PREC_POWER)
                        }
                        Symbol::Root => {
                            let b_s = infix_maybe_paren(&b, b_prec, PREC_POWER, true, false);
                            let a_s = infix_paren_unless_primary(&a, a_prec);
                            (format!("{}**(1/{})", b_s, a_s), PREC_POWER)
                        }
                        Symbol::Log => (format!("log({}, {})", b, a), PREC_ATOM),
                        Symbol::Atan2 => (format!("atan2({}, {})", a, b), PREC_ATOM),
                        _ => unreachable!(),
                    };
                    stack.push((result, prec));
                }
            }
        }

        stack
            .pop()
            .map(|(s, _)| s)
            .unwrap_or_else(|| "?".to_string())
    }
}

impl PartialEq for Expression {
    fn eq(&self, other: &Self) -> bool {
        self.symbols() == other.symbols()
            && self.complexity == other.complexity
            && self.contains_x == other.contains_x
            && self.literal_spans() == other.literal_spans()
    }
}

impl Eq for Expression {}

impl Hash for Expression {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.symbols().hash(state);
        self.complexity.hash(state);
        self.contains_x.hash(state);
        if self.has_decimal_literals() {
            self.literal_spans().hash(state);
        }
    }
}

impl Default for Expression {
    fn default() -> Self {
        Self::new()
    }
}

impl fmt::Display for Expression {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.to_infix())
    }
}

impl fmt::Debug for Expression {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Expr[{}] = {}", self.to_postfix(), self.to_infix())
    }
}

/// An evaluated expression with its numeric value
#[derive(Clone, Debug)]
pub struct EvaluatedExpr {
    /// The symbolic expression
    pub expr: Expression,
    /// Computed value at x = target
    pub value: f64,
    /// Derivative with respect to x
    pub derivative: f64,
    /// Numeric type classification
    ///
    /// This field is part of the public API for library consumers who need
    /// to track the numeric type of evaluated expressions.
    #[allow(dead_code)]
    pub num_type: NumType,
}

impl EvaluatedExpr {
    pub fn new(expr: Expression, value: f64, derivative: f64, num_type: NumType) -> Self {
        Self {
            expr,
            value,
            derivative,
            num_type,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn search_expression_footprint_is_bounded() {
        let symbols = std::mem::size_of::<SmallVec<[Symbol; MAX_EXPR_LEN]>>();
        let expr = std::mem::size_of::<Expression>();
        assert!(expr <= symbols + std::mem::size_of::<usize>());
        #[cfg(target_pointer_width = "64")]
        assert_eq!(expr, 40);
    }

    #[test]
    fn custom_symbol_postfix_roundtrips() {
        for symbols in [
            vec![Symbol::UserConstant0],
            vec![Symbol::Two, Symbol::UserFunction0],
            vec![
                Symbol::UserConstant15,
                Symbol::UserFunction15,
                Symbol::X,
                Symbol::Add,
            ],
        ] {
            let postfix = Expression::from_symbols(&symbols).to_postfix();
            let parsed = Expression::parse(&postfix).expect("canonical postfix parses");
            assert_eq!(parsed.symbols(), symbols.as_slice(), "{postfix:?}");
        }
        // Printable aliases still parse; wide characters are not truncated.
        assert_eq!(
            Expression::parse("2H").unwrap().symbols(),
            &[Symbol::Two, Symbol::UserFunction0]
        );
        assert!(Expression::parse("\u{170}").is_none());
    }

    #[test]
    fn many_live_decimal_literal_annotations_remain_accessible() {
        let mut expressions = Vec::with_capacity(65_536);
        for i in 0..65_536 {
            let mut expr = Expression::parse("2").unwrap();
            expr.mark_decimal_literal(i as f64);
            expressions.push(expr);
        }
        for i in [0, 1, 65_534, 65_535] {
            assert_eq!(expressions[i].decimal_literal_at(0), Some((1, i as f64)));
        }
    }

    #[test]
    fn decimal_literal_survives_clone_and_drop() {
        let mut expr = Expression::parse("2").unwrap();
        let big = 2.0_f64.powi(63);
        expr.mark_decimal_literal(big);
        let cloned = expr.clone();
        drop(expr);
        assert_eq!(cloned.decimal_literal_at(0), Some((1, big)));
        let again = cloned.clone();
        assert_eq!(again, cloned);
        assert_eq!(again.to_infix(), "9223372036854775808");
    }

    #[test]
    fn annotated_clones_are_independent_and_trimmed_on_mutation() {
        use std::collections::hash_map::DefaultHasher;
        let mut left = Expression::parse("2").unwrap();
        left.mark_decimal_literal(2.5);
        let clone = left.clone();
        left.push(Symbol::One);
        left.append_decimal_literals(&clone, 1);
        assert_eq!(left.decimal_literal_at(0), Some((1, 2.5)));
        assert_eq!(left.decimal_literal_at(1), Some((1, 2.5)));
        assert_eq!(clone.decimal_literal_at(1), None);
        assert_eq!(left.pop(), Some(Symbol::One));
        assert_eq!(left, clone);
        let mut a = DefaultHasher::new();
        let mut b = DefaultHasher::new();
        left.hash(&mut a);
        clone.hash(&mut b);
        assert_eq!(a.finish(), b.finish());
        assert_eq!(left.pop(), Some(Symbol::Two));
        assert!(!left.has_decimal_literals());
        assert!(clone.has_decimal_literals());
    }

    #[test]
    fn test_parse_expression() {
        let expr = Expression::parse("32+").unwrap();
        assert_eq!(expr.len(), 3);
        assert_eq!(expr.to_postfix(), "32+");
        assert!(!expr.contains_x());
    }

    #[test]
    fn test_expression_validity() {
        // Valid: 3 2 + (pushes 3, pushes 2, adds them -> 1 value)
        assert!(Expression::parse("32+").unwrap().is_valid());

        // Valid: x 2 ^ (x squared)
        assert!(Expression::parse("xs").unwrap().is_valid());

        // Invalid: 3 + (not enough operands)
        assert!(Expression::parse("3+").is_none());

        // Invalid: 3 2 (two values left on stack)
        assert!(Expression::parse("32").is_none());
    }

    #[test]
    fn test_format_exact_f64_integer_digits() {
        assert_eq!(format_exact_f64_integer(0.0), "0");
        assert_eq!(format_exact_f64_integer(2000002.0), "2000002");
        assert_eq!(format_exact_f64_integer(-12.0), "-12");
        // Independent of the digit-shift formatter: primitive integers.
        for exp in [1_u32, 10, 53, 58, 59, 60, 61, 62, 63, 64, 100, 127] {
            let text = format_exact_f64_integer(2.0_f64.powi(exp as i32));
            let reference = (1_u128 << exp).to_string();
            assert_eq!(text, reference, "2^{exp}");
        }
        let huge = format_exact_f64_integer(2.0_f64.powi(1023));
        assert_eq!(huge.parse::<f64>().unwrap(), 2.0_f64.powi(1023));
        assert_eq!(huge.len(), 308);
        let mut mod_billion = 1u64;
        for _ in 0..1023 {
            mod_billion = (mod_billion * 2) % 1_000_000_000;
        }
        let tail: u64 = huge[huge.len() - 9..].parse().unwrap();
        assert_eq!(tail, mod_billion);
        let max_digits = format_exact_f64_integer(f64::MAX);
        assert_eq!(max_digits.parse::<f64>().unwrap(), f64::MAX);
        assert!(max_digits.bytes().all(|b| b.is_ascii_digit()));
    }

    #[test]
    fn test_infix_conversion() {
        assert_eq!(Expression::parse("32+").unwrap().to_infix(), "3+2");
        assert_eq!(Expression::parse("32*").unwrap().to_infix(), "3*2");
        assert_eq!(Expression::parse("xs").unwrap().to_infix(), "x^2");
        assert_eq!(Expression::parse("xq").unwrap().to_infix(), "sqrt(x)");
        assert_eq!(Expression::parse("32+5*").unwrap().to_infix(), "(3+2)*5");
    }

    #[test]
    fn test_complexity() {
        let expr = Expression::parse("xs").unwrap(); // x^2
                                                     // x = 15, s (square) = 9
        assert_eq!(expr.complexity(), 15 + 9);
    }

    #[test]
    fn test_tree_depth_atom() {
        // Single atom has depth 1
        assert_eq!(Expression::parse("x").unwrap().tree_depth(), 1);
        assert_eq!(Expression::parse("1").unwrap().tree_depth(), 1);
        assert_eq!(Expression::parse("p").unwrap().tree_depth(), 1); // pi
    }

    #[test]
    fn test_tree_depth_unary() {
        // Unary op adds 1 to depth
        assert_eq!(Expression::parse("xq").unwrap().tree_depth(), 2); // sqrt(x)
        assert_eq!(Expression::parse("xs").unwrap().tree_depth(), 2); // x^2
        assert_eq!(Expression::parse("xn").unwrap().tree_depth(), 2); // -x
    }

    #[test]
    fn test_tree_depth_binary() {
        // Binary op takes max of children + 1
        assert_eq!(Expression::parse("12+").unwrap().tree_depth(), 2); // 1+2
        assert_eq!(Expression::parse("x2*").unwrap().tree_depth(), 2); // x*2
        assert_eq!(Expression::parse("x1+2*").unwrap().tree_depth(), 3); // (x+1)*2
    }

    #[test]
    fn test_tree_depth_nested() {
        // Deeply nested expressions
        assert_eq!(Expression::parse("xqq").unwrap().tree_depth(), 3); // sqrt(sqrt(x))
        assert_eq!(Expression::parse("12+34+*").unwrap().tree_depth(), 3); // (1+2)*(3+4)
    }

    #[test]
    fn test_tree_depth_empty() {
        // Empty expression has depth 0
        assert_eq!(Expression::new().tree_depth(), 0);
    }

    #[test]
    fn test_tree_depth_malformed() {
        // Malformed expressions return 0
        assert_eq!(
            Expression::from_symbols(&[Symbol::X, Symbol::One]).tree_depth(),
            0
        );
    }

    #[test]
    fn test_operator_count_atom() {
        // Single atom has no operators
        assert_eq!(Expression::parse("x").unwrap().operator_count(), 0);
        assert_eq!(Expression::parse("1").unwrap().operator_count(), 0);
        assert_eq!(Expression::parse("p").unwrap().operator_count(), 0);
    }

    #[test]
    fn test_operator_count_unary() {
        // Unary op counts as 1 operator
        assert_eq!(Expression::parse("xq").unwrap().operator_count(), 1);
        assert_eq!(Expression::parse("xs").unwrap().operator_count(), 1);
        assert_eq!(Expression::parse("xn").unwrap().operator_count(), 1);
    }

    #[test]
    fn test_operator_count_binary() {
        // Binary op counts as 1 operator
        assert_eq!(Expression::parse("12+").unwrap().operator_count(), 1);
        assert_eq!(Expression::parse("x2*").unwrap().operator_count(), 1);
    }

    #[test]
    fn test_operator_count_complex() {
        // Multiple operators
        assert_eq!(Expression::parse("x1+2*").unwrap().operator_count(), 2); // (x+1)*2
        assert_eq!(Expression::parse("xq1+").unwrap().operator_count(), 2); // sqrt(x)+1
        assert_eq!(Expression::parse("12+34+*").unwrap().operator_count(), 3); // (1+2)*(3+4)
    }

    #[test]
    fn test_operator_count_empty() {
        assert_eq!(Expression::new().operator_count(), 0);
    }

    #[test]
    fn test_push_pop_complexity_saturating() {
        let mut expr = Expression::new();

        // Push should use saturating_add
        for _ in 0..1000 {
            expr.push(Symbol::X);
        }
        // Complexity should saturate, not overflow
        assert!(expr.complexity() < u32::MAX);

        // Pop should use saturating_sub
        for _ in 0..1000 {
            expr.pop();
        }
        // Should be back to 0 without underflow
        assert_eq!(expr.complexity(), 0);
    }

    /// Issue 6: to_infix must not silently produce '?' for invalid expressions.
    /// Instead, stack underflow in the mid-loop pops is a programming error and
    /// should panic with a clear message via expect().
    #[test]
    #[should_panic(expected = "stack underflow in to_infix")]
    fn test_to_infix_panics_on_malformed_expression() {
        // An expression with only a binary operator has no operands — stack underflows
        // on the first pop inside the loop. from_symbols bypasses parse validation.
        let expr = Expression::from_symbols(&[Symbol::Add]);
        let _ = expr.to_infix();
    }

    #[test]
    fn test_try_to_infix_returns_err_on_malformed_expression() {
        // from_symbols bypasses parse validation, producing a malformed postfix string.
        // try_to_infix should return Err(StackUnderflow) rather than panicking.
        let expr = Expression::from_symbols(&[Symbol::Add]);
        let result = expr.try_to_infix();
        assert!(
            result.is_err(),
            "try_to_infix on malformed expression should return Err, got Ok({:?})",
            result.ok()
        );
    }

    #[test]
    fn test_to_infix_or_postfix_falls_back_on_malformed_expression() {
        let expr = Expression::from_symbols(&[Symbol::Add]);
        assert_eq!(expr.to_infix_or_postfix(), expr.to_postfix());
    }

    #[test]
    fn test_try_to_infix_succeeds_on_valid_expression() {
        let expr = Expression::parse("32+").unwrap();
        let result = expr.try_to_infix();
        assert_eq!(result.unwrap(), "3+2");
    }

    #[test]
    fn test_reciprocal_chain_keeps_grouping() {
        // -(1/(1/(-phi))), previously flattened to `-1/1/-phi`.
        assert_eq!(
            Expression::parse("fnrrn").unwrap().to_infix(),
            "-(1/(1/(-phi)))"
        );
    }

    #[test]
    fn test_subtraction_is_left_associative_in_print() {
        assert_eq!(Expression::parse("12-3-").unwrap().to_infix(), "1-2-3");
        assert_eq!(Expression::parse("123--").unwrap().to_infix(), "1-(2-3)");
        assert_eq!(Expression::parse("123+-").unwrap().to_infix(), "1-(2+3)");
    }

    #[test]
    fn test_power_is_right_associative_in_print() {
        assert_eq!(Expression::parse("x23^^").unwrap().to_infix(), "x^2^3");
        assert_eq!(Expression::parse("x2^3^").unwrap().to_infix(), "(x^2)^3");
        assert_eq!(Expression::parse("xss").unwrap().to_infix(), "(x^2)^2");
        assert_eq!(Expression::parse("xsn").unwrap().to_infix(), "-x^2");
        assert_eq!(Expression::parse("xns").unwrap().to_infix(), "(-x)^2");
    }

    #[test]
    fn test_division_of_division_keeps_grouping() {
        assert_eq!(Expression::parse("xrr").unwrap().to_infix(), "1/(1/x)");
        assert_eq!(Expression::parse("xrs").unwrap().to_infix(), "(1/x)^2");
        assert_eq!(Expression::parse("xsr").unwrap().to_infix(), "1/x^2");
    }
}
