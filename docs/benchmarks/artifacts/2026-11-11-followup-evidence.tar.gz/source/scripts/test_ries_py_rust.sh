#!/bin/bash
#
# Run the Rust-side test suite for the PyO3 binding crate without building the
# extension-module flavor. This keeps the test binary linkable while still
# validating the Rust helper logic used by the Python surface.
#
# Usage:
#   ./scripts/test_ries_py_rust.sh
#   ./scripts/test_ries_py_rust.sh test_build_gen_config_includes_preset_user_constants

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"

if [[ -n "${PYO3_PYTHON:-}" ]]; then
    PYTHON_BIN="$PYO3_PYTHON"
elif command -v uv >/dev/null 2>&1; then
    # Prefer a uv-managed interpreter when available. In particular, this
    # avoids the non-linkable Python stubs shipped by some macOS/Xcode setups.
    PYTHON_BIN="$(uv python find --no-project 3.11)"
elif command -v python3 >/dev/null 2>&1; then
    PYTHON_BIN="$(command -v python3)"
else
    echo "Python 3 is required to run ries-py Rust-side tests." >&2
    exit 1
fi

export PYO3_PYTHON="$PYTHON_BIN"

# PyO3 0.30 supports CPython 3.9 and newer. Allow the stable ABI test
# path to proceed when the local interpreter is newer than that window.
export PYO3_USE_ABI3_FORWARD_COMPATIBILITY="${PYO3_USE_ABI3_FORWARD_COMPATIBILITY:-1}"

exec cargo test \
    --manifest-path "$REPO_DIR/ries-py/Cargo.toml" \
    --locked \
    --no-default-features \
    --features parallel \
    "$@"
